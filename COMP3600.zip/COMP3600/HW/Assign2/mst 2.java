/*************************************************************************
 *  Compilation:  javac mst.java
 *  Execution:    java mst
 *  Priority Queue, Disjoint Set, Kruskal, Prim codes are similar to CLRS book
 *  Graphs: CompleteGraph, ConnectedGraph
 *  @author  u6325688
 *************************************************************************/
import java.util.*;

/**
 Minimum Priority Queue: Min Heap
 **/
class MPQueue {
    private List<Node> A;

    MPQueue() {
        A = new ArrayList<>();
    }

    private int parent(int i) {
        return (int) Math.floor(i / 2);
    }

    private int left(int i) {
        return 2 * i;
    }

    private int right(int i) {
        return 2 * i + 1;
    }

    private void swap(int i, int j) {
        Node tmp = A.get(i);
        A.set(i, A.get(j));
        A.set(j, tmp);
    }

    void add(Node x) {
        A.add(x);
        int heap_loc = A.size() - 1;
        decreaseKey(heap_loc, x);
    }

    int getPosition(Node x) {
        return A.indexOf(x);
    }

    Node extract_Min() {
        /*if (A.size() < 0) {
            System.err.println("Queue underflow");
        }*/
        Node min = A.get(0);
        A.set(0, A.get(A.size() - 1));
        A.remove(A.size() - 1);
        min_Heapfify(0);
        return min;
    }

    private void min_Heapfify(int i) {
        int largest;
        int l = left(i);
        int r = right(i);
        if (l <= A.size() - 1 && A.get(l).key < A.get(i).key) {
            largest = l;
        } else {
            largest = i;
        }
        if (r <= A.size() - 1 && A.get(r).key < A.get(largest).key) {
            largest = r;
        }
        if (largest != i) {
            swap(i, largest);
            min_Heapfify(largest);
        }
    }

    void decreaseKey(int i, Node x) {
        if (x.key > A.get(i).key) {
            System.err.println("new Key is " +
                    "smaller than current Key");
            return;
        }
        while (i > 0 &&
                A.get(parent(i)).key > A.get(i).key) {
            swap(i, parent(i));
            i = parent(i);
        }
    }

    boolean isEmpty() {
        return A.size() == 0;
    }

    public int size() {
        return A.size();
    }

}


/**
 Disjoint Set
 **/
class DisjointSet {
    private int[] parent;
    private int[] rank;
    int size;
    DisjointSet(int size) {
        this.parent = new int[size];
        this.rank = new int[size];
        this.size = size;
        makeSet();
    }

    void makeSet(){
        for (int i=0; i<size; i++)
        {
            parent[i] = i;
            rank[i]= 0;
        }
    }

    void union(int v1, int v2){
        link(findSet(v1),findSet(v2));
    }

    private void link(int v1, int v2){
        if (rank[v1] < rank[v2])
            parent[v1] = v2;
        else if (rank[v2] < rank[v1])
            parent[v2] = v1;
        else
        {
            parent[v2] = v1;
            rank[v1] += 1;
        }
        size--;
    }

    int findSet(int v){
        if(v != parent[v]){
            parent[v] = findSet(parent[v]);
        }
        return parent[v];
    }


}

/**
 Node
 **/
class Node {
    int parent;
    int id;
    double x;
    double y;
    double key;

    Node(int id) {
        this.x = Math.random();
        this.y = Math.random();
        this.id = id;
        this.parent = -1;
        this.key = Double.MAX_VALUE;
    }

    public void setParent(int parent) {
        this.parent = parent;
    }

    public void setKey(double key) {
        this.key = key;
    }
}

/**
 Edge
 **/
class Edge {
    Node v1;
    Node v2;
    double w; //weight
    Edge(Node v1, Node v2, double w) {
        this.v1 = v1;
        this.v2 = v2;
        this.w = w;
    }

    void setW(double w){
        this.w = w;
    }
}

/**
 Complete Graph
 **/
class CompleteGraph {
    private double[][] weightGraph;
    ArrayList<Edge> edges;
    int numNode;
    int numEdge;

    public CompleteGraph(Node[] nodes, int size) {
        //Init
        this.numNode = size;
        this.numEdge = size*(size-1)/2; //formula
        this.edges = new ArrayList<>();
        this.weightGraph = new double[size][size];
        //Add weight and edges
        for(int i = 0; i<size;i++){
            Node v1 = nodes[i];
            for (int j = i; j<size; j++){
                Node v2 = nodes[j];
                if(i == j) {
                    this.weightGraph[i][j] = 0;
                    this.weightGraph[j][i] = 0;
                }else {
                    this.weightGraph[i][j] = getWeight(v1,v2);
                    this.weightGraph[j][i] = this.weightGraph[i][j];
                }
                Edge e = new Edge(v1,v2, this.weightGraph[i][j]);
                this.edges.add(e);
            }
        }
        //Sort Edges
        sortEdge();
    }

    private double getWeight(Node v1, Node v2){
        double diff_x = v1.x - v2.x;
        double diff_y = v1.y - v2.y;
        return Math.sqrt(diff_x*diff_x +diff_y*diff_y);
    }

    private void sortEdge(){
        this.edges.sort(new Comparator<Edge>() {
            @Override
            public int compare(Edge c1, Edge c2) {
                return Double.compare(c1.w, c2.w);
            }
        });
    }
}

/**
 Connected Graph
 **/
class ConnectedGraph {
    LinkedList<LinkedList<Node>> adjLists;
    ArrayList<Edge> edges;
    ArrayList<Edge> checkEdges;
    int numNode;
    int numEdge;
    Node[] nodes;
    ConnectedGraph(Node[] nodes, int size){
        this.nodes = nodes;
        //Init
        this.numNode = size;
        this.checkEdges = new ArrayList<>();
        this.edges = new ArrayList<>();
        this.adjLists = new LinkedList<LinkedList<Node>>();
        for (int i = 0; i < size; i++)
            adjLists.add(i, new LinkedList<Node>());
        //Init Disjoint Set
        DisjointSet disjointSet = new DisjointSet(size);
        disjointSet.makeSet();
        //Add weight and edges
        while(disjointSet.size > 1){
            Random rn = new Random();
            int v1_id = rn.nextInt(size);
            int v2_id = rn.nextInt(size);
            Node v1 = nodes[v1_id];
            Node v2 = nodes[v2_id];
            double weight = getWeight(v1,v2);
            Edge e = new Edge(v1,v2,weight);
            //Simulate part-join
            if(!adjLists.get(v1_id).contains(v2) && v1_id != v2_id){
                if (disjointSet.findSet(v1.id) != disjointSet.findSet(v2.id)){
                    disjointSet.union(v1.id,v2.id);
                }
                this.edges.add(e);
                this.checkEdges.add(e);
                this.checkEdges.add(new Edge(v2,v1,weight));
                this.adjLists.get(v1_id).add(v2);
                this.adjLists.get(v2_id).add(v1);
            }
        }
        this.numEdge = edges.size();
    }

    private double getWeight(Node v1, Node v2){
        double diff_x = v1.x - v2.x;
        double diff_y = v1.y - v2.y;
        return Math.sqrt(diff_x*diff_x +diff_y*diff_y);
    }

    void sortEdge(){
        this.edges.sort(new Comparator<Edge>() {
            @Override
            public int compare(Edge c1, Edge c2) {
                return Double.compare(c1.w, c2.w);
            }
        });
    }
}

/**
 Kruskal Algorithm
 **/
class KruskalAlgorithm {
    public double weight;
    public ArrayList<Edge> mst_edges;

    public KruskalAlgorithm(CompleteGraph completeGraph){
        //init
        this.weight = 0;
        this.mst_edges = new ArrayList<Edge>();
        //test Sort
        //System.out.println("");
        //System.out.println("Edge #: " +completeGraph.numEdge);
        /*for(Edge e: completeGraph.edges){
            System.out.println("Edge("+e.v1.id+","+e.v2.id+")==>"+e.w);
        }*/
        //System.out.println("");
        /*for(int i= 0; i < completeGraph. weightGraph.length;i++){
            for(int j= i; j < completeGraph. weightGraph.length;j++){
                System.out.println("Edge("+i+","+j+")==>"+completeGraph.weightGraph[i][j]);
            }
        }*/

        //ArrayList<Edge> edges = completeGraph.edges;
        DisjointSet set = new DisjointSet(completeGraph.numNode);
        for(Edge e: completeGraph.edges){
            int id_v1 = e.v1.id;
            int id_v2 = e.v2.id;
            if(set.findSet(id_v1)!=set.findSet(id_v2)){
                this.mst_edges.add(e);
                set.union(id_v1,id_v2);
                this.weight+=e.w;
            }
        }
        //test MST
        //System.out.println("MSTEdge=>>" +mst_edges.size()+" w = "+weight);
        //for(Edge e: mst_edges){
            //System.out.println("MSTEdge("+e.v1.id+","+e.v2.id+")==>"+e.w);
        //}
    }
    KruskalAlgorithm(ConnectedGraph connectedGraph) {
        this.weight = 0;
        this.mst_edges = new ArrayList<Edge>();
        //Sort Edges
        connectedGraph.sortEdge();
        int num_mstEdge = 0;
        //test Sort
        System.out.println("Edge(" +connectedGraph.numEdge);
        for (Edge e : connectedGraph.edges) {
            System.out.println("Edge(" + e.v1.id + "," + e.v2.id + ")==>" + e.w);
        }

        //ArrayList<Edge> edges = completeGraph.edges;
        DisjointSet set = new DisjointSet(connectedGraph.numNode);
        for(Edge e: connectedGraph.edges){
            int id_v1 = e.v1.id;
            int id_v2 = e.v2.id;
            if(set.findSet(id_v1)!=set.findSet(id_v2)){
                mst_edges.add(e);
                set.union(id_v1,id_v2);
                this.weight+=e.w;
            }
        }
        //test MST
        System.out.println("MSTEdge=>>" +mst_edges.size()+" w = "+weight);
        for (Edge e : mst_edges) {
            System.out.println("MSTEdge(" + e.v1.id + "," + e.v2.id + ")==>" + e.w);
        }
    }

}

/**
 Prim Algorithm
 **/
class PrimAlgorithm {
    private MPQueue queue;
    private Node[] primNodes;
    private Boolean[] isInPrimMST;

     double getWeight(Node v1, Node v2){
        double diff_x = v1.x - v2.x;
        double diff_y = v1.y - v2.y;
        return Math.sqrt(diff_x*diff_x +diff_y*diff_y);
    }

    PrimAlgorithm(ConnectedGraph connectedGraph){
        //Init
        queue = new MPQueue();
        primNodes = new Node[connectedGraph.numNode];
        isInPrimMST = new Boolean[connectedGraph.numNode];
        for(int pn = 0;pn<connectedGraph.numNode;pn++){
            isInPrimMST[pn]=false;
        }
        //Set Queue
        //primNodes[0].key = 0;
        connectedGraph.nodes[0].key = 0;
        isInPrimMST[0]=true;

        for (Node n:connectedGraph.nodes){
            queue.add(n);
        }
        //Test AdjList
        /*int adjSize = connectedGraph.adjLists.size();
        for (int i = 0; i< adjSize; i++) {
            System.out.print("Node["+i+"] has=>");
            for(Node n: connectedGraph.adjLists.get(i)){
                System.out.print(" "+n.id);
            }
            System.out.println("");
        }
        System.out.println("");
        System.out.println("Edge #: " + connectedGraph.numEdge);
        for(Edge e: connectedGraph.edges){
            System.out.println("Edge("+e.v1.id+","+e.v2.id+")==>"+e.w);
        }
        System.out.println();*/

        while (!queue.isEmpty()){
            Node u = queue.extract_Min();
            isInPrimMST[u.id] = true;
            //System.out.println("Extract Node["+u.id+"]   Key="+u.key+" Parent="+u.parent);
            for(Node v : connectedGraph.adjLists.get(u.id)){
                double weight = getWeight(u,v);
                if(isInPrimMST[v.id] == false && weight<v.key){
                    v.parent = u.id;
                    v.key = weight;
                    queue.decreaseKey(queue.getPosition(v),v);
                }
            }
        }
        System.out.println();
        for(Node n: connectedGraph.nodes){
            if(n.parent!=-1)
            System.out.println("Node["+n.id+"] -->"+n.parent);
        }

    }
}

public class mst {

    /**
     Generate Random points
     **/
    private static Node[] generatePoints(int size){
        Node[] nodes = new Node[size];
        for(int i = 0; i < size; i++){
            nodes[i]= new Node(i);
        }
        return nodes;
    }

    public static void main(String[] args){
        /**** Generate Complete Graph ****/
        /*
        int numGraph = 1;
        //int numGroup[] = {100,500,1000,5000}; //num of nodes in each group
        int numGroup[] = {10,50,100,500}; //num of nodes in each group
        double weights[] = new double[numGroup.length];
        for(int i = 0; i < numGroup.length;i++){
            int node_size = numGroup[i];
            for(int j = 0; j < numGraph; j++) {
                CompleteGraph completeGraph = new CompleteGraph(generatePoints(node_size), node_size);
                KruskalAlgorithm kruskalAlgorithm = new KruskalAlgorithm(completeGraph);
                weights[i] += kruskalAlgorithm.weight;
                System.out.println(weights[i]);
            }
            weights[i] = weights[i]/numGraph; //store average weight
            System.out.println("When n = "+node_size+";  --"
                    + numGraph+"-- MST average weight = "+ weights[i]);
        }
        */
        /* Calculate the trend sum L(n) of Complete Graph */


        /* Generate Connected Graph */
        int numGraph = 1;
        //int numGroup[] = {100,500,1000,5000}; //num of nodes in each group
        int numGroup[] = {5}; //num of nodes in each group
        double weights[] = new double[numGroup.length];
        for(int i = 0; i < numGroup.length;i++){
            int node_size = numGroup[i];
            for(int j = 0; j < numGraph; j++) {
                ConnectedGraph connectedGraph = new ConnectedGraph(generatePoints(node_size), node_size);
                KruskalAlgorithm kruskalAlgorithm = new KruskalAlgorithm(connectedGraph);
                PrimAlgorithm primAlgorithm = new PrimAlgorithm(connectedGraph);
                //weights[i] += kruskalAlgorithm.weight;
                //System.out.println(weights[i]);
            }
            //weights[i] = weights[i]/numGraph; //store average weight
            /*System.out.println("When n = "+node_size+";  --"
                    + numGraph+"-- MST average weight = "+ weights[i]);*/
        }

        /**** Test Running Time ****/


    }
}